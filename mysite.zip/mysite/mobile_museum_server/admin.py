from django.contrib import admin
from .models import ItemNew
from .models import ItemImageNew
from .models import exhibitionInfo
from .models import exhibitionImage
from .models import Favorite
from .models import History
from .models import BankAccount
from .models import Ticket

# Register your models here.
admin.site.register(ItemNew)
admin.site.register(ItemImageNew)
admin.site.register(exhibitionInfo)
admin.site.register(exhibitionImage)
admin.site.register(Favorite)
admin.site.register(History)
admin.site.register(BankAccount)
admin.site.register(Ticket)
