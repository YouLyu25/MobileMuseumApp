from django.urls import path, include
from django.contrib import admin
from django.contrib.auth.views import login, logout
from . import views

admin.autodiscover()

urlpatterns = [
    path('getItemInfo/', views.getItemInfo, name='getItemInfo'),
    path('getItemImage/', views.getItemImage, name='getItemImage'),
    path('getExhibitionInfo/', views.getExhibitionInfo, name='getExhibitionInfo'),
    path('getExhibitionInfoSingle/', views.getExhibitionInfoSingle, name='getExhibitionInfoSingle'),
    path('getExhibitionImage/', views.getExhibitionImage, name='getExhibitionImage'),
    path('searchItem/', views.searchItem, name='searchItem'),
    path('updateHistory/', views.updateHistory, name='updateHistory'),
    path('deleteHistory/', views.deleteHistory, name='deleteHistory'),
    path('getHistory/', views.getHistory, name='getHistory'),
    path('getTicketInfo/', views.getTicketInfo, name='getTicketInfo'),
    path('updateTicketInfo/', views.updateTicketInfo, name='updateTicketInfo'),
    path('buyTicket/', views.buyTicket, name='buyTicket'),
    path('addUser/', views.addUser, name='addUser'),
    path('logout/', views.logout, name='logout'),
    path('authentication/',views.authentication, name = 'authentication'),
    path('getRandomItemName/', views.getRandomItemName, name='getRandomItemName'),
    path('getRandomItemImage/', views.getRandomItemImage, name='getRandomItemImage'),
    path('checkFavoriteItem/', views.checkFavoriteItem, name='checkFavoriteItem'),
    path('addFavoriteItem/', views.addFavoriteItem, name='addFavoriteItem'),
    path('removeFavoriteItem/', views.removeFavoriteItem, name='removeFavoriteItem'),
    path('getFavoriteItemNames/', views.getFavoriteItemNames, name='getFavoriteItemNames'),
]

