from django.db import models
from django.contrib.auth.models import AbstractUser
from django.contrib.postgres.fields import ArrayField

# Create your models here.
# deprecated...
class Item (models.Model):
    #id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=50)
    material = models.CharField(max_length=50)
    year = models.CharField(max_length=30)
    dynasty = models.CharField(max_length=50)
    intro = models.CharField(max_length=300)
    
    def __str__(self):
        return self.name


# deprecated...
class ItemImage (models.Model):
    #id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=50)
    path = models.CharField(max_length=200)
    
    def __str__(self):
        return self.name



class ItemNew (models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=50)
    material = models.CharField(max_length=50)
    year = models.CharField(max_length=30)
    dynasty = models.CharField(max_length=50)
    intro = models.CharField(max_length=300)

    def __str__(self):
        return self.name



class ItemImageNew (models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=50)
    path = models.CharField(max_length=200)

    def __str__(self):
        return self.name



class exhibitionInfo (models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=50)
    location = models.CharField(max_length=50)
    intro = models.CharField(max_length=300)
    
    def __str__(self):
        return self.name



class exhibitionImage (models.Model):
    id = models.AutoField(primary_key=True)
    name = models.CharField(max_length=50)
    path = models.CharField(max_length=200)
    
    def __str__(self):
        return self.name



class Favorite (models.Model):
    id = models.AutoField(primary_key=True)
    username = models.CharField(max_length=50)
    itemName = models.CharField(max_length=50)
    
    
    
class History (models.Model):
    id = models.AutoField(primary_key=True)
    username = models.CharField(max_length=50)
    itemName = models.CharField(max_length=50)
    time = models.DateTimeField(auto_now=True)



class Ticket (models.Model):
    username = models.CharField(max_length=50)
    date = models.CharField(max_length=50)
    code = models.CharField(max_length=10)



class BankAccount (models.Model):
    cardNumber = models.CharField(max_length=16)
    ownerName = models.CharField(max_length=50)
    cvv = models.CharField(max_length=3)
