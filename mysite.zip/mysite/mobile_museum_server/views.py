from django.shortcuts import render, HttpResponse, redirect
from django.db import models
from django.contrib.auth import authenticate
from django.contrib.auth.models import User
from django.contrib.auth import login as auth_login
from django.contrib.auth import logout as auth_logout
from django.contrib.auth.decorators import login_required
from .models import ItemNew
from .models import ItemImageNew
from .models import exhibitionInfo
from .models import exhibitionImage
from .models import Favorite
from .models import History
from .models import BankAccount
from .models import Ticket
import json
from django.core import serializers
import os
import os.path
from django.core.files import File


# Create your views here.

def getItemInfo (request):
    bodyUnicode = request.body.decode('utf-8')
    body = json.loads(bodyUnicode)
    itemName = body["name"]
    #print("check: " + itemName + " len: " + str(len(itemName)))
    res = ItemNew.objects.filter(name__iexact=itemName)
    if not res:
        return HttpResponse("item not found...")
    else:
        item_info = ""
        temp = str(res.values_list("name")[0])
        temp = temp[2:len(temp)-3]
        item_info += "Item Name: " + temp + "\n\n"
        
        temp = str(res.values_list("material")[0])
        temp = temp[2:len(temp)-3]
        item_info += "Material: " + temp + "\n\n"
        
        temp = str(res.values_list("year")[0])
        temp = temp[2:len(temp)-3]
        item_info += "Year: " + temp + "\n\n"
        
        temp = str(res.values_list("dynasty")[0])
        temp = temp[2:len(temp)-3]
        item_info += "Dynasty: " + temp + "\n\n"
        
        temp = str(res.values_list("intro")[0])
        temp = temp[2:len(temp)-3]
        item_info += "Introduction: " + temp + "\n"
        
#        return HttpResponse(list(res.values()))
        return HttpResponse(item_info)



def getItemImage (request):
    bodyUnicode = request.body.decode('utf-8')
    body = json.loads(bodyUnicode)
    itemName = body["name"]
    #print("look: " + itemName)
    res = ItemImageNew.objects.filter(name__iexact=itemName)
    
    currPath = os.getcwd()
    relativePath = str(res.values_list("path")[0])
    relativePath = relativePath[2:len(relativePath)-3]
    itemPath = currPath + relativePath
    #print(itemPath)
    imageData = open(itemPath, 'rb').read()
    return HttpResponse(imageData) #, content_type="image/png")



def getExhibitionInfo (request):
    bodyUnicode = request.body.decode('utf-8')
    body = json.loads(bodyUnicode)
    res = exhibitionInfo.objects.all()
    if len(res) == 0:
        return HttpResponse("not found")
    else:
        exhibition = ""
        for i in range(len(res)):
            temp = str(res.values_list("name")[i])
            temp = temp[2:len(temp)-3]
            exhibition += temp + "@"
        exhibition = exhibition[0:len(exhibition)-1]
        #print("exhibitionInfo: " + exhibition)
        return HttpResponse(exhibition)



def getExhibitionInfoSingle (request):
    bodyUnicode = request.body.decode('utf-8')
    body = json.loads(bodyUnicode)
    exhibitionName = body["name"]
    res = exhibitionInfo.objects.filter(name=exhibitionName)
    if len(res) == 0:
        return HttpResponse("not found")
    else:
        exhibition = ""
        temp = str(res.values_list("name")[0])
        temp = temp[2:len(temp)-3]
        exhibition += temp + "\n\nLocation: "
        temp = str(res.values_list("location")[0])
        temp = temp[2:len(temp)-3]
        exhibition += temp + "\n\nIntroduction:\n"
        temp = str(res.values_list("intro")[0])
        temp = temp[2:len(temp)-3]
        exhibition += temp
        #print("exhibitionInfo: " + exhibition)
        return HttpResponse(exhibition)



def getExhibitionImage (request):
    bodyUnicode = request.body.decode('utf-8')
    body = json.loads(bodyUnicode)
    exhibitionName = body["name"]
    res = exhibitionImage.objects.filter(name=exhibitionName)
    
    currPath = os.getcwd()
    relativePath = str(res.values_list("path")[0])
    relativePath = relativePath[2:len(relativePath)-3]
    exhibitionPath = currPath + relativePath
    #print(itemPath)
    imageData = open(exhibitionPath, 'rb').read()
    return HttpResponse(imageData)



def searchItem (request):
    bodyUnicode = request.body.decode('utf-8')
    body = json.loads(bodyUnicode)
    itemName = body["name"]
    if itemName != "":
        res = ItemImageNew.objects.filter(name__icontains=itemName)
        itemNames = ""
        # get favorite item names and store in a string
        if len(res) == 0: # no item in the list
            return HttpResponse("not found")
        for i in range(len(res)):
            temp = str(res.values_list("name")[i])
            temp = temp[2:len(temp)-3]
            itemNames += temp + "@"
        itemNames = itemNames[0:len(itemNames)-1]
        #print(itemNames)
        return HttpResponse(itemNames)
    else:
        return HttpResponse("invalid item name")



def updateHistory (request):
    bodyUnicode = request.body.decode('utf-8')
    body = json.loads(bodyUnicode)
    username = body["username"]
    itemName = body["itemName"]
    if username != "":
        history = History.objects.update_or_create(username=username,
                                                   itemName=itemName,
                                                   defaults={"username": username,
                                                             "itemName": itemName})
    return HttpResponse("updated")



def deleteHistory (request):
    bodyUnicode = request.body.decode('utf-8')
    body = json.loads(bodyUnicode)
    username = body["username"]
    if username != "":
        history = History.objects.filter(username=username)
        if history:
            history.delete()
    return HttpResponse("success")



def getHistory (request):
    bodyUnicode = request.body.decode('utf-8')
    body = json.loads(bodyUnicode)
    username = body["username"]
    if username != "":
        res = History.objects.filter(username=username).order_by("-time")
        itemNames = ""
        # get favorite item names and store in a string
        if len(res) == 0: # no item in the list
            return HttpResponse("not found")
        for i in range(len(res)):
            temp = str(res.values_list("itemName")[i])
            temp = temp[2:len(temp)-3]
            itemNames += temp + "@"
            #print(temp)
        itemNames = itemNames[0:len(itemNames)-1]
        return HttpResponse(itemNames)
    else:
        return HttpResponse("invalid item name")



def getRandomItemName (request):
    bodyUnicode = request.body.decode('utf-8')
    body = json.loads(bodyUnicode)
    index = body["index"]
    if index != "":
        # generate random number
        #print(index)
        res = ItemNew.objects.filter(id=int(index))
        if not res:
            return HttpResponse("item not found...")
        else:
            item_info = ""
            temp = str(res.values_list("name")[0])
            temp = temp[2:len(temp)-3]
            item_info += temp
            return HttpResponse(item_info)
    return HttpResponse("item not found...")



def getRandomItemImage (request):
    bodyUnicode = request.body.decode('utf-8')
    body = json.loads(bodyUnicode)
    index = body["index"]
    if index != "":
        # generate random number
        res = ItemImageNew.objects.filter(id=int(index))
        currPath = os.getcwd()
        relativePath = str(res.values_list("path")[0])
        relativePath = relativePath[2:len(relativePath)-3]
        itemPath = currPath + relativePath
        #print("random path: " + itemPath)
        imageData = open(itemPath, 'rb').read()
        return HttpResponse(imageData)



#@login_required
def checkFavoriteItem (request):
    bodyUnicode = request.body.decode('utf-8')
    body = json.loads(bodyUnicode)
    username = body["username"]
    itemName = body["itemName"]
    if itemName != "":
        res = Favorite.objects.filter(username=username, itemName=itemName)
        if res: # found in the favorite list
            return HttpResponse("successfully found")
        else: # not found in the list
            return HttpResponse("not found")
    return HttpResponse("invalid item name")



#@login_required
def addFavoriteItem (request):
    bodyUnicode = request.body.decode('utf-8')
    body = json.loads(bodyUnicode)
    username = body["username"]
    itemName = body["itemName"]
    if itemName != "":
        res = Favorite.objects.filter(username=username, itemName=itemName)
        if not res: # not in the favorite list, add to the list
            favorite = Favorite.objects.create(username=username, itemName=itemName)
            favorite.save()
            return HttpResponse("successfully added")
        else: # already in the list, cannot add
            return HttpResponse("already in the list")
    return HttpResponse("invalid item name")



#@login_required
def removeFavoriteItem (request):
    bodyUnicode = request.body.decode('utf-8')
    body = json.loads(bodyUnicode)
    username = body["username"]
    itemName = body["itemName"]
    if itemName != "":
        res = Favorite.objects.filter(username=username, itemName=itemName)
        if res: # found in the favorite list, remove
            res.delete()
            return HttpResponse("successfully deleted")
        else: # not found in the list, cannot remove
            return HttpResponse("not found")
    return HttpResponse("invalid item name")



def getFavoriteItemNames (request):
    bodyUnicode = request.body.decode('utf-8')
    body = json.loads(bodyUnicode)
    username = body["username"]
    if username != "":
        res = Favorite.objects.filter(username=username)
        itemNames = ""
        # get favorite item names and store in a string
        if len(res) == 0: # no item in the list
            return HttpResponse("not found")
        for i in range(len(res)):
            temp = str(res.values_list("itemName")[i])
            temp = temp[2:len(temp)-3]
            itemNames += temp + "@"
        itemNames = itemNames[0:len(itemNames)-1]
        #print(itemNames)
        return HttpResponse(itemNames)
    else:
        return HttpResponse("invalid item name")



def getTicketInfo (request):
    bodyUnicode = request.body.decode('utf-8')
    body = json.loads(bodyUnicode)
    username = body["username"]
    if username != "":
        res = Ticket.objects.filter(username=username)
        ticketInfo = ""
        # get favorite item names and store in a string
        if len(res) == 0: # no item in the list
            return HttpResponse("not found")
        for i in range(len(res)):
            temp = str(res.values_list("date")[i])
            temp = temp[2:len(temp)-3]
            ticketInfo += temp + "   verification code: "
            temp = str(res.values_list("code")[i])
            temp = temp[2:len(temp)-3]
            ticketInfo += temp + "@"
        ticketInfo = ticketInfo[0:len(ticketInfo)-1]
        #print(ticketInfo)
        return HttpResponse(ticketInfo)
    else:
        return HttpResponse("invalid item name")



# TODO
def buyTicket (request):
    bodyUnicode = request.body.decode('utf-8')
    body = json.loads(bodyUnicode)
    cardNumber = body["cardNumber"]
    ownerName = body["ownerName"]
    cvv = body["cvv"]
    if cardNumber != "":
        res = BankAccount.objects.filter(cardNumber=cardNumber, ownerName__iexact=ownerName, cvv=cvv)
        if res:
            return HttpResponse("success")
        return HttpResponse("failure")
    else:
        return HttpResponse("invalid item name")



def updateTicketInfo (request):
    bodyUnicode = request.body.decode('utf-8')
    body = json.loads(bodyUnicode)
    username = body["username"]
    date = body["date"]
    code = body["verificationCode"]
    res = Ticket.objects.filter(username=username, date=date)
    if len(res) >= 3: # cannot buy more than three tickets for a single day
        return HttpResponse("fail")
    ticket = Ticket.objects.create(username=username, date=date, code=code)
    ticket.save()
    return HttpResponse("successfully booked ticket!")



@login_required
def logout(request):
    auth_logout(request)
    return HttpResponse("logout!")



def addUser(request):
    bodyUnicode = request.body.decode('utf-8')
    body = json.loads(bodyUnicode)
    username = body["username"]
    password = body["password"]
    email = body["email"]
    confirm = body["confirm"]
    #print(confirm)
    #print(password)
    user = User.objects.filter(username__exact=username)
    if confirm!=password:
        return HttpResponse("confirm fail!")
    if not user:
        user = User.objects.create_user(username=username, email=email, password=password)
        user.save()
        return HttpResponse("successfully registered!")
    else:
        return HttpResponse("username already exists, please choose a cooler name!")


    
def authentication(request):
    bodyUnicode = request.body.decode('utf-8')
    body = json.loads(bodyUnicode)
    username = body["username"]
    password = body["password"]
    user = authenticate(username=username, password=password)

    if user is not None:
        auth_login(request,user)
        #img = request.user.avatar
        args = {'username':username}
        return render(request, 'login_succeed.html',args)
    else:
        return HttpResponse(status=403)

