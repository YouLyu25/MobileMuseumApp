from django.apps import AppConfig


class MobileMuseumServerConfig(AppConfig):
    name = 'mobile_museum_server'
